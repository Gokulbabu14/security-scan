import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from fastapi import FastAPI, HTTPException, BackgroundTasks
from fastapi.responses import FileResponse
from pydantic import BaseModel
from scanner.sql_injection import run_sql_injection
from utils.rg import (
    analyze_headers, check_open_redirect_improved, check_directory_listing, check_sensitive_files_improved, check_xss_reflection_improved, check_csrf_token, check_admin_panel, check_ssl_certificate, check_clickjacking, check_http_methods, check_robots_and_security_txt, check_api_endpoints, check_csp_policy_strength, check_email_disclosure, check_backup_files, check_exposed_git_svn, check_outdated_js_libs,
    generate_report, generate_pdf_report
)
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

class ScanRequest(BaseModel):
    target_url: str
    attack_types: list[str]

@app.post("/analyze")
async def analyze(request: ScanRequest, background_tasks: BackgroundTasks):
    scan_id = request.target_url.replace("https://", "").replace("/", "_")
    # Map attack_types to functions
    check_map = {
        "sql_injection": lambda: background_tasks.add_task(run_sql_injection, request.target_url, scan_id),
        "headers": lambda: background_tasks.add_task(analyze_headers, request.target_url),
        "open_redirect": lambda: background_tasks.add_task(check_open_redirect_improved, request.target_url),
        "directory_listing": lambda: background_tasks.add_task(check_directory_listing, request.target_url),
        "sensitive_files": lambda: background_tasks.add_task(check_sensitive_files_improved, request.target_url),
        "xss": lambda: background_tasks.add_task(check_xss_reflection_improved, request.target_url),
        "csrf": lambda: background_tasks.add_task(check_csrf_token, request.target_url),
        "admin_panel": lambda: background_tasks.add_task(check_admin_panel, request.target_url),
        "ssl": lambda: background_tasks.add_task(check_ssl_certificate, request.target_url),
        "clickjacking": lambda: background_tasks.add_task(check_clickjacking, request.target_url),
        "http_methods": lambda: background_tasks.add_task(check_http_methods, request.target_url),
        "robots": lambda: background_tasks.add_task(check_robots_and_security_txt, request.target_url),
        "api": lambda: background_tasks.add_task(check_api_endpoints, request.target_url),
        "csp": lambda: background_tasks.add_task(check_csp_policy_strength, request.target_url),
        "email": lambda: background_tasks.add_task(check_email_disclosure, request.target_url),
        "backup": lambda: background_tasks.add_task(check_backup_files, request.target_url),
        "git_svn": lambda: background_tasks.add_task(check_exposed_git_svn, request.target_url),
        "js_libs": lambda: background_tasks.add_task(check_outdated_js_libs, request.target_url),
    }
    for attack in request.attack_types:
        if attack in check_map:
            check_map[attack]()
    return {"message": "Scan started", "scan_id": scan_id}

@app.get("/report/{scan_id}")
async def get_report(scan_id: str):
    try:
        return generate_report(scan_id)
    except FileNotFoundError:
        raise HTTPException(status_code=404, detail="Report not found")

@app.get("/report/{scan_id}/pdf")
async def get_report_pdf(scan_id: str):
    try:
        report_data = generate_report(scan_id)
        pdf_path = generate_pdf_report(scan_id, report_data)
        return FileResponse(pdf_path, media_type='application/pdf', filename=f'{scan_id}_report.pdf')
    except FileNotFoundError:
        raise HTTPException(status_code=404, detail="Report not found")

# Serve React static files
static_dir = os.path.join(os.path.dirname(__file__), "static")
if os.path.exists(static_dir):
    app.mount("/", StaticFiles(directory=static_dir, html=True), name="static")

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app", host="127.0.0.1", port=8000, reload=True)